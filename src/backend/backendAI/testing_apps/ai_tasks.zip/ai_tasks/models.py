# No models - Redis only for task storage
